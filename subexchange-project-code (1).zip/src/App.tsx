import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { EarnSection } from './components/EarnSection';
import { CreateCampaignSection } from './components/CreateCampaignSection';
import { DashboardProfile } from './components/DashboardProfile';
import { TaskPlayerModal } from './components/TaskPlayerModal';
import { AuthModal } from './components/AuthModal';
import { WalletModal } from './components/WalletModal';
import { ExportModal } from './components/ExportModal';
import { BottomNavigation } from './components/BottomNavigation';
import { 
  Play, 
  Youtube, 
  ShieldCheck, 
  Sparkles, 
  Coins, 
  Users, 
  Lock,
  Heart
} from 'lucide-react';

function MainApp() {
  const { 
    activeTab, 
    activeWatchTask, 
    setActiveWatchTask,
    currentUser
  } = useApp();

  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      
      {/* Top Navigation Bar with persistent Coin balance */}
      <Navbar 
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16 md:pb-8">
        {activeTab === 'earn' && (
          <EarnSection onOpenAuth={() => setIsAuthOpen(true)} />
        )}

        {activeTab === 'create' && (
          <CreateCampaignSection 
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenWallet={() => setIsWalletOpen(true)}
          />
        )}

        {activeTab === 'dashboard' && (
          <DashboardProfile 
            onOpenWallet={() => setIsWalletOpen(true)}
            onOpenAuth={() => setIsAuthOpen(true)}
            onOpenExport={() => setIsExportOpen(true)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 py-8 px-4 text-center text-xs text-slate-500 dark:text-slate-400 hidden md:block">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-xs">
              <Play className="w-3.5 h-3.5 fill-white" />
            </div>
            <span className="font-extrabold text-slate-900 dark:text-white">
              SubExchange
            </span>
            <span>— The Fair Creator Growth Network</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified Watch Retention
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-amber-500">
              <Coins className="w-3.5 h-3.5" />
              50 Starter Coins On Signup
            </span>
            <span>•</span>
            <span className="flex items-center gap-1 text-red-500">
              <Youtube className="w-3.5 h-3.5" />
              Organic YouTube Reach
            </span>
          </div>

          <div className="text-[11px] text-slate-400">
            © {new Date().getFullYear()} SubExchange. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <BottomNavigation
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
      />

      {/* Modals */}
      <TaskPlayerModal
        campaign={activeWatchTask}
        onClose={() => setActiveWatchTask(null)}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
      />

      <WalletModal
        isOpen={isWalletOpen}
        onClose={() => setIsWalletOpen(false)}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
