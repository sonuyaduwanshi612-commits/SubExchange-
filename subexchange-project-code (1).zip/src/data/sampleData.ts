import { Campaign, User, CoinTransaction } from '../types';

export const INITIAL_SAMPLE_CAMPAIGNS: Campaign[] = [
  {
    id: 'camp-seed-1',
    creatorId: 'user-seed-1',
    creatorName: 'Marcus Vance',
    creatorChannel: 'TechPulse Daily',
    creatorChannelUrl: 'https://youtube.com/@TechPulseDaily',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    videoId: 'dQw4w9WgXcQ',
    videoTitle: 'Top 10 AI Productivity Tools That Save 20+ Hours Every Week',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
    type: 'sub_watch',
    requiredWatchSeconds: 20,
    rewardCoins: 15,
    targetQuantity: 20,
    currentCompleted: 14,
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    completedUserIds: []
  },
  {
    id: 'camp-seed-2',
    creatorId: 'user-seed-2',
    creatorName: 'Elena Rostova',
    creatorChannel: 'CyberByte Gaming',
    creatorChannelUrl: 'https://youtube.com/@CyberByteGaming',
    videoUrl: 'https://www.youtube.com/watch?v=M7lc1UVf-VE',
    videoId: 'M7lc1UVf-VE',
    videoTitle: 'Unreal Engine 5 Next-Gen Graphics Showcase - Cinematic Teaser',
    thumbnailUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
    type: 'sub_watch',
    requiredWatchSeconds: 15,
    rewardCoins: 10,
    targetQuantity: 30,
    currentCompleted: 22,
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
    completedUserIds: []
  },
  {
    id: 'camp-seed-3',
    creatorId: 'user-seed-3',
    creatorName: 'DevNotes & Code',
    creatorChannel: 'DevNotes',
    creatorChannelUrl: 'https://youtube.com/@DevNotesCode',
    videoUrl: 'https://www.youtube.com/watch?v=L_LUpnjgPso',
    videoId: 'L_LUpnjgPso',
    videoTitle: 'React 19 Server Components Explained in 10 Minutes with Examples',
    thumbnailUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80',
    type: 'view_watch',
    requiredWatchSeconds: 25,
    rewardCoins: 12,
    targetQuantity: 15,
    currentCompleted: 8,
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    completedUserIds: []
  },
  {
    id: 'camp-seed-4',
    creatorId: 'user-seed-4',
    creatorName: 'ChillVibes Beats',
    creatorChannel: 'Aura Lofi Station',
    creatorChannelUrl: 'https://youtube.com/@AuraLofiBeats',
    videoUrl: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
    videoId: 'jfKfPfyJRdk',
    videoTitle: 'Deep Focus & Study Session - Instrumental Hip-Hop Beats [24/7]',
    thumbnailUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
    type: 'quick_view',
    requiredWatchSeconds: 10,
    rewardCoins: 8,
    targetQuantity: 50,
    currentCompleted: 39,
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 36).toISOString(),
    completedUserIds: []
  },
  {
    id: 'camp-seed-5',
    creatorId: 'user-seed-5',
    creatorName: 'Kairos Finance',
    creatorChannel: 'Smart Money Hacks',
    creatorChannelUrl: 'https://youtube.com/@SmartMoneyHacks',
    videoUrl: 'https://www.youtube.com/watch?v=k1BneeJTDcU',
    videoId: 'k1BneeJTDcU',
    videoTitle: 'How Beginner Creators Hit 1,000 Subscribers & Get Monetized Fast',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579532537598-459ecdaf39cc?auto=format&fit=crop&w=800&q=80',
    type: 'sub_watch',
    requiredWatchSeconds: 20,
    rewardCoins: 14,
    targetQuantity: 25,
    currentCompleted: 11,
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    completedUserIds: []
  }
];

export const DEMO_USER: User = {
  id: 'user-demo-primary',
  name: 'Alex Rivera',
  email: 'alex.creator@example.com',
  channelName: 'Alex Builds Stuff',
  channelUrl: 'https://youtube.com/@AlexBuildsStuff',
  coins: 50, // Starts with 50 bonus coins as required!
  totalEarned: 50,
  totalSpent: 0,
  joinedAt: new Date().toISOString(),
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
};

export const INITIAL_TRANSACTIONS: CoinTransaction[] = [
  {
    id: 'tx-welcome-demo',
    userId: 'user-demo-primary',
    amount: 50,
    type: 'bonus',
    description: 'Welcome Bonus: 50 Free Starter Coins',
    timestamp: new Date().toISOString()
  }
];
