import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Campaign, CoinTransaction, TaskCompletionLog, CampaignType } from '../types';
import { INITIAL_SAMPLE_CAMPAIGNS, DEMO_USER, INITIAL_TRANSACTIONS } from '../data/sampleData';
import { extractYouTubeVideoId, getYouTubeThumbnailUrl, formatYouTubeChannelUrl } from '../utils/youtube';
import { sound } from '../utils/audio';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  campaigns: Campaign[];
  transactions: CoinTransaction[];
  completedTasks: TaskCompletionLog[];
  isDarkMode: boolean;
  activeTab: 'earn' | 'create' | 'dashboard' | 'wallet';
  setActiveTab: (tab: 'earn' | 'create' | 'dashboard' | 'wallet') => void;
  toggleTheme: () => void;
  login: (email: string) => boolean;
  signup: (name: string, email: string, channelName: string, channelUrl: string) => User;
  loginAsDemo: () => void;
  logout: () => void;
  completeTask: (campaignId: string) => { success: boolean; coinsAwarded: number; message: string };
  createCampaign: (data: {
    videoUrl: string;
    videoTitle: string;
    type: CampaignType;
    requiredWatchSeconds: number;
    targetQuantity: number;
    rewardCoins: number;
  }) => { success: boolean; message: string };
  deleteCampaign: (campaignId: string) => { success: boolean; refundCoins: number };
  togglePauseCampaign: (campaignId: string) => void;
  claimDailyBonus: () => { success: boolean; coinsAwarded: number; message: string };
  activeWatchTask: Campaign | null;
  setActiveWatchTask: (campaign: Campaign | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'subexchange_current_user',
  USERS: 'subexchange_all_users',
  CAMPAIGNS: 'subexchange_campaigns',
  TRANSACTIONS: 'subexchange_transactions',
  COMPLETED_TASKS: 'subexchange_completed_tasks',
  THEME: 'subexchange_theme',
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Dark mode state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    const saved = localStorage.getItem(STORAGE_KEYS.THEME);
    return saved !== null ? saved === 'dark' : true; // default to dark
  });

  // Current active navigation tab
  const [activeTab, setActiveTab] = useState<'earn' | 'create' | 'dashboard' | 'wallet'>('earn');

  // Currently watching/completing task modal
  const [activeWatchTask, setActiveWatchTask] = useState<Campaign | null>(null);

  // Users repository
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USERS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [DEMO_USER];
  });

  // Active User state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEMO_USER;
  });

  // Campaigns list
  const [campaigns, setCampaigns] = useState<Campaign[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CAMPAIGNS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_SAMPLE_CAMPAIGNS;
  });

  // Transactions list
  const [transactions, setTransactions] = useState<CoinTransaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_TRANSACTIONS;
  });

  // Completed tasks log
  const [completedTasks, setCompletedTasks] = useState<TaskCompletionLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COMPLETED_TASKS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  // Sync theme to DOM
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.THEME, isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  // Persist state changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CAMPAIGNS, JSON.stringify(campaigns));
  }, [campaigns]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPLETED_TASKS, JSON.stringify(completedTasks));
  }, [completedTasks]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentUser));
      // Also update in users list
      setUsers(prev => prev.map(u => u.id === currentUser.id ? currentUser : u));
    } else {
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  }, [currentUser]);

  const toggleTheme = () => setIsDarkMode(prev => !prev);

  // Authentication: Signup
  const signup = (name: string, email: string, channelName: string, rawChannelUrl: string): User => {
    const channelUrl = formatYouTubeChannelUrl(rawChannelUrl);
    const avatarNumber = Math.floor(Math.random() * 70) + 1;
    const newUser: User = {
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      channelName: channelName.trim() || `${name}'s Channel`,
      channelUrl,
      coins: 50, // EVERY new user starts with 50 bonus coins as required!
      totalEarned: 50,
      totalSpent: 0,
      joinedAt: new Date().toISOString(),
      avatarUrl: `https://i.pravatar.cc/150?img=${avatarNumber}`
    };

    // Add initial bonus transaction
    const welcomeTx: CoinTransaction = {
      id: `tx-welcome-${Date.now()}`,
      userId: newUser.id,
      amount: 50,
      type: 'bonus',
      description: 'Welcome Bonus: 50 Free Starter Coins',
      timestamp: new Date().toISOString()
    };

    setUsers(prev => [...prev.filter(u => u.email !== newUser.email), newUser]);
    setTransactions(prev => [welcomeTx, ...prev]);
    setCurrentUser(newUser);
    sound.playSuccessSound();
    return newUser;
  };

  // Authentication: Login
  const login = (email: string): boolean => {
    const trimmed = email.trim().toLowerCase();
    const found = users.find(u => u.email.toLowerCase() === trimmed);
    if (found) {
      setCurrentUser(found);
      sound.playCoinSound();
      return true;
    }
    return false;
  };

  const loginAsDemo = () => {
    setCurrentUser(DEMO_USER);
    sound.playCoinSound();
  };

  const logout = () => {
    setCurrentUser(null);
    setActiveWatchTask(null);
  };

  // Complete a Task and Earn Coins
  const completeTask = (campaignId: string) => {
    if (!currentUser) {
      return { success: false, coinsAwarded: 0, message: 'Please log in first' };
    }

    const campaign = campaigns.find(c => c.id === campaignId);
    if (!campaign) {
      return { success: false, coinsAwarded: 0, message: 'Campaign not found' };
    }

    if (campaign.completedUserIds.includes(currentUser.id)) {
      return { success: false, coinsAwarded: 0, message: 'You have already completed this campaign' };
    }

    if (campaign.creatorId === currentUser.id) {
      return { success: false, coinsAwarded: 0, message: 'You cannot complete your own campaign' };
    }

    const reward = campaign.rewardCoins;
    const now = new Date().toISOString();

    // 1. Update user coins
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        coins: prev.coins + reward,
        totalEarned: prev.totalEarned + reward,
      };
    });

    // 2. Record transaction
    const newTx: CoinTransaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: currentUser.id,
      amount: reward,
      type: 'task_reward',
      description: `Earned for watching "${campaign.videoTitle.substring(0, 32)}..."`,
      timestamp: now,
      referenceId: campaign.id
    };
    setTransactions(prev => [newTx, ...prev]);

    // 3. Record task completion log
    const taskLog: TaskCompletionLog = {
      id: `task-log-${Date.now()}`,
      userId: currentUser.id,
      campaignId: campaign.id,
      campaignTitle: campaign.videoTitle,
      channelName: campaign.creatorChannel,
      rewardCoins: reward,
      completedAt: now
    };
    setCompletedTasks(prev => [taskLog, ...prev]);

    // 4. Update campaign completed count and user list
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const nextCompleted = c.currentCompleted + 1;
        const nextStatus = nextCompleted >= c.targetQuantity ? 'completed' : c.status;
        return {
          ...c,
          currentCompleted: nextCompleted,
          status: nextStatus,
          completedUserIds: [...c.completedUserIds, currentUser.id]
        };
      }
      return c;
    }));

    sound.playCoinSound();

    return {
      success: true,
      coinsAwarded: reward,
      message: `Successfully earned +${reward} coins!`
    };
  };

  // Create a new Campaign
  const createCampaign = (data: {
    videoUrl: string;
    videoTitle: string;
    type: CampaignType;
    requiredWatchSeconds: number;
    targetQuantity: number;
    rewardCoins: number;
  }) => {
    if (!currentUser) {
      return { success: false, message: 'Please log in to create campaigns' };
    }

    const totalCost = data.targetQuantity * data.rewardCoins;
    if (currentUser.coins < totalCost) {
      return {
        success: false,
        message: `Insufficient coins. You have ${currentUser.coins} coins but need ${totalCost} coins.`
      };
    }

    const videoId = extractYouTubeVideoId(data.videoUrl) || 'dQw4w9WgXcQ';
    const thumbnailUrl = getYouTubeThumbnailUrl(videoId);
    const now = new Date().toISOString();

    const newCampaign: Campaign = {
      id: `camp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      creatorChannel: currentUser.channelName,
      creatorChannelUrl: currentUser.channelUrl,
      videoUrl: data.videoUrl,
      videoId,
      videoTitle: data.videoTitle.trim() || `${currentUser.channelName} Video`,
      thumbnailUrl,
      type: data.type,
      requiredWatchSeconds: data.requiredWatchSeconds,
      rewardCoins: data.rewardCoins,
      targetQuantity: data.targetQuantity,
      currentCompleted: 0,
      status: 'active',
      createdAt: now,
      completedUserIds: []
    };

    // Deduct coins from user's wallet
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        coins: prev.coins - totalCost,
        totalSpent: prev.totalSpent + totalCost
      };
    });

    // Record transaction
    const spendTx: CoinTransaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: currentUser.id,
      amount: -totalCost,
      type: 'campaign_create',
      description: `Created campaign: ${data.targetQuantity} targets at ${data.rewardCoins} coins each`,
      timestamp: now,
      referenceId: newCampaign.id
    };
    setTransactions(prev => [spendTx, ...prev]);

    // Add campaign to public list
    setCampaigns(prev => [newCampaign, ...prev]);

    sound.playSuccessSound();

    return {
      success: true,
      message: `Campaign created! ${totalCost} coins deducted from your balance.`
    };
  };

  // Delete Campaign & Refund remaining uncompleted coins
  const deleteCampaign = (campaignId: string) => {
    if (!currentUser) return { success: false, refundCoins: 0 };

    const campaign = campaigns.find(c => c.id === campaignId && c.creatorId === currentUser.id);
    if (!campaign) return { success: false, refundCoins: 0 };

    const remainingSlots = Math.max(0, campaign.targetQuantity - campaign.currentCompleted);
    const refundAmount = remainingSlots * campaign.rewardCoins;

    if (refundAmount > 0) {
      setCurrentUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          coins: prev.coins + refundAmount,
          totalSpent: Math.max(0, prev.totalSpent - refundAmount)
        };
      });

      const refundTx: CoinTransaction = {
        id: `tx-refund-${Date.now()}`,
        userId: currentUser.id,
        amount: refundAmount,
        type: 'campaign_refund',
        description: `Refund for deleted campaign (${remainingSlots} uncompleted slots)`,
        timestamp: new Date().toISOString(),
        referenceId: campaign.id
      };
      setTransactions(prev => [refundTx, ...prev]);
    }

    setCampaigns(prev => prev.filter(c => c.id !== campaignId));
    sound.playCoinSound();

    return { success: true, refundCoins: refundAmount };
  };

  const togglePauseCampaign = (campaignId: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        const nextStatus = c.status === 'paused' ? 'active' : 'paused';
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  // Daily Bonus Claim
  const claimDailyBonus = () => {
    if (!currentUser) {
      return { success: false, coinsAwarded: 0, message: 'Please log in' };
    }

    const now = new Date();
    if (currentUser.lastDailyBonusClaim) {
      const lastClaim = new Date(currentUser.lastDailyBonusClaim);
      const diffHours = (now.getTime() - lastClaim.getTime()) / (1000 * 60 * 60);
      if (diffHours < 24) {
        const remainingHours = Math.ceil(24 - diffHours);
        return {
          success: false,
          coinsAwarded: 0,
          message: `Daily bonus available in ${remainingHours} hours.`
        };
      }
    }

    const bonusAmount = 15;
    setCurrentUser(prev => {
      if (!prev) return null;
      return {
        ...prev,
        coins: prev.coins + bonusAmount,
        totalEarned: prev.totalEarned + bonusAmount,
        lastDailyBonusClaim: now.toISOString()
      };
    });

    const tx: CoinTransaction = {
      id: `tx-daily-${Date.now()}`,
      userId: currentUser.id,
      amount: bonusAmount,
      type: 'daily_claim',
      description: 'Daily Check-in Bonus',
      timestamp: now.toISOString()
    };
    setTransactions(prev => [tx, ...prev]);

    sound.playSuccessSound();

    return {
      success: true,
      coinsAwarded: bonusAmount,
      message: `Awesome! Claimed +${bonusAmount} daily bonus coins!`
    };
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        campaigns,
        transactions,
        completedTasks,
        isDarkMode,
        activeTab,
        setActiveTab,
        toggleTheme,
        login,
        signup,
        loginAsDemo,
        logout,
        completeTask,
        createCampaign,
        deleteCampaign,
        togglePauseCampaign,
        claimDailyBonus,
        activeWatchTask,
        setActiveWatchTask,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
