// Utility for parsing YouTube URLs and extracting video ID

export function extractYouTubeVideoId(url: string): string | null {
  if (!url) return null;
  const cleanUrl = url.trim();

  // Handle standard watch URLs: https://www.youtube.com/watch?v=VIDEO_ID
  const watchRegex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
  const match = cleanUrl.match(watchRegex);
  if (match && match[1]) {
    return match[1];
  }

  // Handle shorts: https://www.youtube.com/shorts/VIDEO_ID
  const shortsRegex = /youtube\.com\/shorts\/([^"&?\/\s]{11})/i;
  const shortsMatch = cleanUrl.match(shortsRegex);
  if (shortsMatch && shortsMatch[1]) {
    return shortsMatch[1];
  }

  // If already an 11-char ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(cleanUrl)) {
    return cleanUrl;
  }

  return null;
}

export function getYouTubeThumbnailUrl(videoId: string): string {
  if (!videoId) return 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=600&q=80';
  return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
}

export function formatYouTubeChannelUrl(input: string): string {
  if (!input) return 'https://youtube.com';
  const trimmed = input.trim();
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }
  if (trimmed.startsWith('@')) {
    return `https://youtube.com/${trimmed}`;
  }
  return `https://youtube.com/@${trimmed}`;
}
