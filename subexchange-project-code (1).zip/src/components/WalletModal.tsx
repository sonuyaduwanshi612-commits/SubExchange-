import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Coins, 
  Gift, 
  ArrowUpRight, 
  ArrowDownLeft, 
  TrendingUp, 
  Clock, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({ isOpen, onClose }) => {
  const { 
    currentUser, 
    transactions, 
    claimDailyBonus, 
    setActiveTab 
  } = useApp();

  const [claimToast, setClaimToast] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen || !currentUser) return null;

  const handleClaimBonus = () => {
    const res = claimDailyBonus();
    setClaimToast(res);
    setTimeout(() => setClaimToast(null), 3500);
  };

  const userTransactions = transactions.filter(t => t.userId === currentUser.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="wallet-modal-dialog"
        className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        
        {/* Wallet Header with Glowing Coin Balance */}
        <div className="relative p-6 sm:p-7 bg-gradient-to-br from-amber-500 via-yellow-500 to-amber-600 text-slate-950 overflow-hidden">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/15 hover:bg-black/25 flex items-center justify-center text-slate-950 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <div className="w-7 h-7 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center shadow-md">
              <Coins className="w-4 h-4" />
            </div>
            <span className="text-xs font-black uppercase tracking-wider text-slate-900/80">
              Creator Coin Wallet
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-4xl sm:text-5xl font-black tracking-tight text-slate-950">
              {currentUser.coins}
            </span>
            <span className="text-sm font-bold uppercase tracking-wider text-slate-900/80">
              Coins
            </span>
          </div>

          <p className="text-xs text-slate-900/80 mt-1 font-medium">
            Use coins to get real YouTube subscribers, views, and high-retention watch time.
          </p>

          {/* Quick Stats bar inside header */}
          <div className="mt-5 grid grid-cols-2 gap-3 p-3 rounded-2xl bg-black/10 backdrop-blur-md">
            <div>
              <span className="text-[10px] font-bold text-slate-900/70 block">Lifetime Earned</span>
              <span className="text-sm font-black text-slate-950">+{currentUser.totalEarned} Coins</span>
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-900/70 block">Lifetime Spent</span>
              <span className="text-sm font-black text-slate-950">-{currentUser.totalSpent} Coins</span>
            </div>
          </div>
        </div>

        {/* Daily Bonus Section */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 flex items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <Gift className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <span>Daily Free Coins</span>
                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-400 text-[10px] font-black">
                    +15 Free
                  </span>
                </h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Log in every 24 hours to collect free coins.
                </p>
              </div>
            </div>

            <button
              id="btn-claim-daily-bonus-modal"
              onClick={handleClaimBonus}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shrink-0 shadow-sm transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Claim</span>
            </button>
          </div>

          {claimToast && (
            <div className={`mt-2.5 p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              claimToast.success 
                ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                : 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
            }`}>
              {claimToast.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{claimToast.message}</span>
            </div>
          )}
        </div>

        {/* Action Shortcuts */}
        <div className="p-4 grid grid-cols-2 gap-3 border-b border-slate-100 dark:border-slate-800">
          <button
            onClick={() => {
              setActiveTab('earn');
              onClose();
            }}
            className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-left transition-colors group"
          >
            <span className="text-[10px] font-bold text-red-600 dark:text-red-400 uppercase tracking-wider block">
              Need More Coins?
            </span>
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center justify-between mt-0.5">
              <span>Watch Tasks</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </span>
          </button>

          <button
            onClick={() => {
              setActiveTab('create');
              onClose();
            }}
            className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-left transition-colors group"
          >
            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider block">
              Spend Coins
            </span>
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center justify-between mt-0.5">
              <span>New Campaign</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </span>
          </button>
        </div>

        {/* Transaction History */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
          <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
            Transaction Activity
          </h4>

          {userTransactions.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No transactions recorded yet.
            </div>
          ) : (
            <div className="space-y-2">
              {userTransactions.map(tx => {
                const isEarn = tx.amount > 0;
                return (
                  <div
                    key={tx.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs ${
                        isEarn
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'bg-red-500/10 text-red-600 dark:text-red-400'
                      }`}>
                        {isEarn ? <ArrowDownLeft className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                          {tx.description}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {new Date(tx.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </p>
                      </div>
                    </div>

                    <span className={`text-xs font-mono font-bold whitespace-nowrap ${
                      isEarn ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                    }`}>
                      {isEarn ? `+${tx.amount}` : tx.amount} c
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
