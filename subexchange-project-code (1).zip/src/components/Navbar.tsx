import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Coins, 
  Sun, 
  Moon, 
  PlusCircle, 
  Play, 
  User as UserIcon, 
  LogOut, 
  Gift, 
  Wallet,
  Sparkles,
  Layers,
  ChevronDown,
  Download,
  FolderArchive
} from 'lucide-react';

interface NavbarProps {
  onOpenAuth: () => void;
  onOpenWallet: () => void;
  onOpenExport: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAuth, onOpenWallet, onOpenExport }) => {
  const { 
    currentUser, 
    logout, 
    isDarkMode, 
    toggleTheme, 
    activeTab, 
    setActiveTab, 
    claimDailyBonus 
  } = useApp();

  const [showUserMenu, setShowUserMenu] = useState(false);
  const [bonusToast, setBonusToast] = useState<string | null>(null);

  const handleDailyBonus = () => {
    const res = claimDailyBonus();
    setBonusToast(res.message);
    setTimeout(() => setBonusToast(null), 3500);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800/80 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Brand Logo */}
        <div 
          id="nav-brand"
          onClick={() => setActiveTab('earn')}
          className="flex items-center gap-2.5 cursor-pointer select-none group"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-600 via-rose-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-red-500/20 group-hover:scale-105 transition-transform">
            <Play className="w-5 h-5 fill-white" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-900 dark:text-white">
                Sub<span className="text-red-600 dark:text-red-500">Exchange</span>
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                PRO
              </span>
            </div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 hidden sm:block -mt-1 font-medium">
              YouTube Growth Network
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-900/90 p-1 rounded-xl border border-slate-200 dark:border-slate-800">
          <button
            id="nav-tab-earn"
            onClick={() => setActiveTab('earn')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
              activeTab === 'earn'
                ? 'bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Play className="w-4 h-4" />
            Earn Coins
          </button>

          <button
            id="nav-tab-create"
            onClick={() => setActiveTab('create')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
              activeTab === 'create'
                ? 'bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            Create Campaign
          </button>

          <button
            id="nav-tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
              activeTab === 'dashboard'
                ? 'bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            My Dashboard
          </button>
        </nav>

        {/* Right Section: Coin Wallet Badge, Theme Toggle, Profile */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Coin Balance Badge (Always visible on top of dashboard) */}
          {currentUser && (
            <div className="flex items-center gap-1.5">
              <button
                id="header-coin-badge"
                onClick={onOpenWallet}
                title="View Wallet & Transactions"
                className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-400/15 to-yellow-500/10 dark:from-amber-500/20 dark:to-yellow-500/20 border border-amber-500/30 text-amber-700 dark:text-amber-300 hover:border-amber-500/60 transition-all shadow-sm group"
              >
                <div className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black text-xs shadow group-hover:rotate-12 transition-transform">
                  <Coins className="w-3.5 h-3.5 text-slate-950" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-extrabold text-sm sm:text-base leading-none text-slate-900 dark:text-amber-300">
                    {currentUser.coins}
                  </span>
                  <span className="text-[9px] uppercase font-bold tracking-wider text-amber-600 dark:text-amber-400 hidden sm:inline">
                    Coins
                  </span>
                </div>
                <ChevronDown className="w-3 h-3 text-amber-600/70 dark:text-amber-400/70 hidden sm:block" />
              </button>

              {/* Daily Claim Quick Button */}
              <button
                id="btn-daily-bonus-quick"
                onClick={handleDailyBonus}
                title="Claim Daily Free Coins (+15)"
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 text-xs font-semibold transition-all"
              >
                <Gift className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>+15 Daily</span>
              </button>
            </div>
          )}

          {/* Download ZIP / Export Code Button */}
          <button
            id="btn-nav-export-zip"
            onClick={onOpenExport}
            title="Download Full Project ZIP & GitHub Export Guide"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100 font-bold text-xs shadow-sm transition-all active:scale-95"
          >
            <Download className="w-3.5 h-3.5 text-red-500 animate-pulse" />
            <span className="hidden sm:inline">Download ZIP</span>
            <span className="sm:hidden">ZIP</span>
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            id="btn-theme-toggle"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 transition-colors"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
          </button>

          {/* User Profile / Auth Button */}
          {currentUser ? (
            <div className="relative">
              <button
                id="btn-user-avatar"
                onClick={() => setShowUserMenu(prev => !prev)}
                className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-900 border border-transparent hover:border-slate-200 dark:hover:border-slate-800 transition-all"
              >
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-lg object-cover ring-2 ring-red-500/30"
                />
                <div className="text-left hidden xl:block">
                  <p className="text-xs font-bold text-slate-900 dark:text-white leading-tight truncate max-w-[110px]">
                    {currentUser.name}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[110px]">
                    {currentUser.channelName}
                  </p>
                </div>
              </button>

              {/* User Dropdown */}
              {showUserMenu && (
                <div 
                  id="user-dropdown-menu"
                  className="absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2"
                >
                  <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800">
                    <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {currentUser.name}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {currentUser.email}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-xs px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                      <span className="text-slate-500 dark:text-slate-400">Balance:</span>
                      <span className="font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                        <Coins className="w-3.5 h-3.5" />
                        {currentUser.coins} Coins
                      </span>
                    </div>
                  </div>

                  <div className="p-1">
                    <button
                      id="dropdown-profile"
                      onClick={() => {
                        setActiveTab('dashboard');
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      Channel Profile & Stats
                    </button>

                    <button
                      id="dropdown-wallet"
                      onClick={() => {
                        onOpenWallet();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Wallet className="w-4 h-4 text-amber-500" />
                      Wallet & Transactions
                    </button>

                    <button
                      id="dropdown-claim"
                      onClick={() => {
                        handleDailyBonus();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition-colors"
                    >
                      <Gift className="w-4 h-4" />
                      Claim Daily Bonus (+15)
                    </button>

                    <button
                      id="dropdown-export-zip"
                      onClick={() => {
                        onOpenExport();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                    >
                      <Download className="w-4 h-4 text-red-500" />
                      Download Project (.ZIP)
                    </button>
                  </div>

                  <div className="pt-1 border-t border-slate-100 dark:border-slate-800 px-1">
                    <button
                      id="dropdown-logout"
                      onClick={() => {
                        logout();
                        setShowUserMenu(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      Log Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              id="btn-login-open"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs sm:text-sm font-bold shadow-md shadow-red-600/20 transition-all"
            >
              <UserIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>Login / Sign Up</span>
            </button>
          )}
        </div>
      </div>

      {/* Daily Bonus Feedback Toast */}
      {bonusToast && (
        <div className="bg-emerald-500 text-white text-xs font-medium py-1.5 px-4 text-center flex items-center justify-center gap-2 shadow-sm animate-in fade-in slide-in-from-top">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{bonusToast}</span>
        </div>
      )}
    </header>
  );
};
