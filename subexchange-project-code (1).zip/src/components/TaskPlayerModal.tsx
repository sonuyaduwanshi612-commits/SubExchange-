import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Campaign } from '../types';
import { 
  X, 
  Play, 
  Pause, 
  Coins, 
  Check, 
  CheckCircle2, 
  ExternalLink, 
  Youtube, 
  Sparkles, 
  Clock, 
  ShieldAlert, 
  Flame,
  Volume2
} from 'lucide-react';

interface TaskPlayerModalProps {
  campaign: Campaign | null;
  onClose: () => void;
}

export const TaskPlayerModal: React.FC<TaskPlayerModalProps> = ({ campaign, onClose }) => {
  const { completeTask, currentUser } = useApp();

  const requiredSeconds = campaign ? campaign.requiredWatchSeconds || 15 : 15;
  const [secondsLeft, setSecondsLeft] = useState<number>(requiredSeconds);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isSubscribed, setIsSubscribed] = useState<boolean>(false);
  const [isClaimed, setIsClaimed] = useState<boolean>(false);
  const [claimResult, setClaimResult] = useState<string | null>(null);

  // Reset timer on campaign change
  useEffect(() => {
    if (campaign) {
      setSecondsLeft(campaign.requiredWatchSeconds || 15);
      setIsPlaying(true);
      setIsSubscribed(false);
      setIsClaimed(false);
      setClaimResult(null);
    }
  }, [campaign]);

  // Countdown timer loop
  useEffect(() => {
    if (!campaign || isClaimed || !isPlaying) return;

    if (secondsLeft <= 0) return;

    const timer = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [campaign, isPlaying, secondsLeft, isClaimed]);

  if (!campaign) return null;

  const isTimerComplete = secondsLeft === 0;
  const progressPercent = Math.min(100, Math.round(((requiredSeconds - secondsLeft) / requiredSeconds) * 100));

  const handleClaim = () => {
    if (!currentUser) return;
    if (!isTimerComplete) return;

    const res = completeTask(campaign.id);
    if (res.success) {
      setIsClaimed(true);
      setClaimResult(res.message);
      setTimeout(() => {
        onClose();
      }, 2200);
    } else {
      setClaimResult(res.message);
    }
  };

  const isTaskCompletedAlready = currentUser && campaign.completedUserIds.includes(currentUser.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        id="task-player-modal"
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]"
      >
        
        {/* Top bar */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30 flex items-center justify-center">
              <Youtube className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block leading-tight truncate max-w-[200px] sm:max-w-md">
                {campaign.videoTitle}
              </span>
              <span className="text-[10px] text-slate-400">
                Reward: <strong className="text-amber-400">+{campaign.rewardCoins} Coins</strong> • Watch {requiredSeconds}s
              </span>
            </div>
          </div>

          <button
            id="btn-close-player"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video Player Display Area */}
        <div className="relative bg-black aspect-video w-full flex items-center justify-center overflow-hidden group">
          {/* Iframe or Realistic Fallback Player */}
          {campaign.videoId ? (
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${campaign.videoId}?autoplay=1&mute=0&controls=1&rel=0`}
              title={campaign.videoTitle}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          ) : (
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={campaign.thumbnailUrl}
                alt={campaign.videoTitle}
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
            </div>
          )}

          {/* Overlay timer badge in corner of player */}
          <div className="absolute top-3 left-3 z-10 px-3 py-1.5 rounded-xl bg-black/80 backdrop-blur-md border border-white/10 text-white flex items-center gap-2 shadow-lg">
            <Clock className={`w-3.5 h-3.5 ${isTimerComplete ? 'text-emerald-400' : 'text-amber-400 animate-pulse'}`} />
            <span className="text-xs font-mono font-bold">
              {isTimerComplete ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Watch Time Met!
                </span>
              ) : (
                <span>00:{secondsLeft.toString().padStart(2, '0')} required</span>
              )}
            </span>
          </div>

          {/* Quick Play/Pause Timer Control */}
          <button
            onClick={() => setIsPlaying(prev => !prev)}
            className="absolute bottom-3 right-3 z-10 px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black/90 text-white text-xs flex items-center gap-1.5 border border-white/10"
          >
            {isPlaying ? (
              <>
                <Pause className="w-3 h-3 text-amber-400" />
                <span className="text-[10px]">Pause Timer</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3 text-emerald-400" />
                <span className="text-[10px]">Resume Timer</span>
              </>
            )}
          </button>
        </div>

        {/* Verification & Channel Action Bar */}
        <div className="p-4 sm:p-5 space-y-4 overflow-y-auto">
          
          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-red-400" />
                Verification Progress:
              </span>
              <span className={isTimerComplete ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                {isTimerComplete ? '100% Completed' : `${progressPercent}% (${secondsLeft}s left)`}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div 
                className={`h-full transition-all duration-300 ${
                  isTimerComplete 
                    ? 'bg-emerald-500' 
                    : 'bg-gradient-to-r from-red-600 via-amber-500 to-emerald-400'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Channel Card & Subscribe Action */}
          <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center font-bold text-white shadow">
                {campaign.creatorChannel.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-white">
                    {campaign.creatorChannel}
                  </span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <a
                  href={campaign.creatorChannelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-slate-400 hover:text-red-400 flex items-center gap-1 transition-colors"
                >
                  <span>Open channel on YouTube</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            {/* Subscribe toggle button */}
            <button
              id="btn-subscribe-toggle"
              onClick={() => setIsSubscribed(prev => !prev)}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md ${
                isSubscribed
                  ? 'bg-slate-700 text-slate-200 border border-slate-600'
                  : 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/30'
              }`}
            >
              {isSubscribed ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Subscribed ✓</span>
                </>
              ) : (
                <>
                  <Youtube className="w-3.5 h-3.5" />
                  <span>Subscribe Now</span>
                </>
              )}
            </button>
          </div>

          {/* Anti-cheat guidelines */}
          <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-950/40 p-2.5 rounded-xl border border-slate-800">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Fair-Exchange Policy: Watch the video for full duration and stay subscribed to keep your verified standing.</span>
          </div>

          {/* Claim Action */}
          <div>
            {isTaskCompletedAlready ? (
              <div className="p-3 text-center rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>You have already completed this task and earned your coins!</span>
              </div>
            ) : isClaimed ? (
              <div className="p-4 text-center rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold flex items-center justify-center gap-2 animate-bounce">
                <Sparkles className="w-5 h-5 text-amber-300" />
                <span>{claimResult || `+${campaign.rewardCoins} Coins Added to your Wallet!`}</span>
              </div>
            ) : (
              <button
                id="btn-claim-reward"
                disabled={!isTimerComplete}
                onClick={handleClaim}
                className={`w-full py-3 px-4 rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
                  isTimerComplete
                    ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 shadow-amber-500/30 hover:scale-[1.02] cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                }`}
              >
                <Coins className={`w-4 h-4 ${isTimerComplete ? 'text-slate-950 animate-bounce' : 'text-slate-500'}`} />
                <span>
                  {isTimerComplete
                    ? `Claim +${campaign.rewardCoins} Coins Now!`
                    : `Watch ${secondsLeft}s more to unlock +${campaign.rewardCoins} Coins`}
                </span>
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
