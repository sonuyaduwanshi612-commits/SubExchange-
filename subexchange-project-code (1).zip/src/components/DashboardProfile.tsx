import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Coins, 
  Layers, 
  CheckCircle2, 
  Youtube, 
  ExternalLink, 
  Trash2, 
  Pause, 
  Play, 
  Calendar, 
  TrendingUp, 
  History, 
  Gift, 
  Award,
  Sparkles,
  PlusCircle,
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
  Download,
  Github,
  FileArchive
} from 'lucide-react';

interface DashboardProfileProps {
  onOpenWallet: () => void;
  onOpenAuth: () => void;
  onOpenExport?: () => void;
}

export const DashboardProfile: React.FC<DashboardProfileProps> = ({ onOpenWallet, onOpenAuth, onOpenExport }) => {
  const { 
    currentUser, 
    campaigns, 
    completedTasks, 
    transactions, 
    deleteCampaign, 
    togglePauseCampaign, 
    setActiveTab,
    claimDailyBonus
  } = useApp();

  const [activeTabSub, setActiveTabSub] = useState<'my_campaigns' | 'task_history' | 'transactions'>('my_campaigns');

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto my-12 p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-4 shadow-sm">
        <div className="w-14 h-14 rounded-2xl bg-red-600/10 text-red-600 mx-auto flex items-center justify-center">
          <Youtube className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">
          Sign In to View Dashboard
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Access your coin wallet, active campaigns, completed task logs, and channel growth analytics.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-600/20"
        >
          Sign In / Sign Up
        </button>
      </div>
    );
  }

  // Filter user's campaigns
  const myCampaigns = campaigns.filter(c => c.creatorId === currentUser.id);
  const activeCampaignsCount = myCampaigns.filter(c => c.status === 'active').length;

  // Determine Creator Badge
  const totalTasksCompleted = completedTasks.length;
  let creatorTier = 'Bronze Creator';
  let tierColor = 'from-amber-700 to-amber-900 text-amber-200 border-amber-600/30';

  if (totalTasksCompleted >= 20 || currentUser.totalEarned >= 200) {
    creatorTier = 'Gold Creator Partner';
    tierColor = 'from-amber-400 to-yellow-600 text-slate-950 border-amber-300';
  } else if (totalTasksCompleted >= 5 || currentUser.totalEarned >= 80) {
    creatorTier = 'Silver Rising Creator';
    tierColor = 'from-slate-400 to-slate-600 text-white border-slate-300';
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20">
      
      {/* Profile Header Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4 sm:gap-5">
          <img
            src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}
            alt={currentUser.name}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-4 ring-red-500/20 shadow-md"
          />

          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                {currentUser.name}
              </h1>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r ${tierColor} border shadow-sm`}>
                {creatorTier}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-1 font-semibold text-red-600 dark:text-red-400">
                <Youtube className="w-3.5 h-3.5" />
                <span>{currentUser.channelName}</span>
              </div>
              <span>•</span>
              <a
                href={currentUser.channelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline flex items-center gap-1 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
              >
                <span>Channel Link</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              <Calendar className="w-3 h-3" />
              <span>Joined SubExchange {new Date(currentUser.joinedAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        {/* Quick actions right */}
        <div className="flex sm:flex-col items-center sm:items-end gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('create')}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md shadow-red-600/20 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Campaign</span>
          </button>
          
          <button
            onClick={onOpenWallet}
            className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-2 border border-slate-200 dark:border-slate-700 transition-colors"
          >
            <Coins className="w-4 h-4 text-amber-500" />
            <span>Wallet Details</span>
          </button>

          {onOpenExport && (
            <button
              id="btn-dashboard-download-zip"
              onClick={onOpenExport}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-white dark:hover:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <Download className="w-4 h-4 text-red-500" />
              <span>Download Code (.ZIP)</span>
            </button>
          )}
        </div>
      </div>

      {/* Code Export Banner */}
      {onOpenExport && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-red-600/10 via-rose-500/10 to-amber-500/10 border border-red-500/20 dark:border-red-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <FileArchive className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                Download Full Source Code / Export to GitHub
                <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-600 dark:text-red-400 text-[10px] font-extrabold uppercase">
                  1-Click
                </span>
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Poora source code (.zip) apne computer par download karein ya AI Studio se direct GitHub par export karein.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenExport}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold flex items-center justify-center gap-2 shadow-md shadow-red-600/20 transition-all shrink-0 active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download ZIP / GitHub Guide</span>
          </button>
        </div>
      )}

      {/* 4 Stat Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Metric 1: Current Coin Balance */}
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-amber-500/10 via-amber-400/5 to-transparent border border-amber-500/20 dark:border-amber-500/30 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Current Coins
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-sm">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-amber-300">
              {currentUser.coins}
            </span>
            <p className="text-[10px] text-amber-700 dark:text-amber-400/80 font-semibold mt-0.5">
              Available to spend
            </p>
          </div>
        </div>

        {/* Metric 2: Total Coins Earned */}
        <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Total Earned
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-black">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              +{currentUser.totalEarned}
            </span>
            <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold mt-0.5">
              Lifetime coins earned
            </p>
          </div>
        </div>

        {/* Metric 3: Active Campaigns */}
        <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Active Campaigns
            </span>
            <div className="w-8 h-8 rounded-xl bg-red-500/10 text-red-600 dark:text-red-400 flex items-center justify-center font-black">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {activeCampaignsCount}
            </span>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
              {myCampaigns.length} total campaigns created
            </p>
          </div>
        </div>

        {/* Metric 4: Completed Tasks */}
        <div className="p-4 sm:p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
              Tasks Completed
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-black">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {totalTasksCompleted}
            </span>
            <p className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold mt-0.5">
              Videos watched & supported
            </p>
          </div>
        </div>

      </div>

      {/* Tabs for Campaigns / History / Transactions */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        
        {/* Navigation sub-tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-4 pt-3 bg-slate-50/50 dark:bg-slate-900/50 gap-2">
          <button
            onClick={() => setActiveTabSub('my_campaigns')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTabSub === 'my_campaigns'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>My Campaigns ({myCampaigns.length})</span>
          </button>

          <button
            onClick={() => setActiveTabSub('task_history')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTabSub === 'task_history'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Completed Tasks ({completedTasks.length})</span>
          </button>

          <button
            onClick={() => setActiveTabSub('transactions')}
            className={`pb-3 px-3 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-1.5 ${
              activeTabSub === 'transactions'
                ? 'border-red-600 text-red-600 dark:text-red-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>Coin Ledger ({transactions.length})</span>
          </button>
        </div>

        {/* Tab 1: My Campaigns List */}
        {activeTabSub === 'my_campaigns' && (
          <div className="p-4 sm:p-6 space-y-4">
            {myCampaigns.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/50 text-red-500 mx-auto flex items-center justify-center">
                  <Layers className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  You haven't launched any campaigns yet
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Use your coins to promote your YouTube videos, gain authentic subscribers, and get high-retention views!
                </p>
                <button
                  onClick={() => setActiveTab('create')}
                  className="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold shadow-md hover:bg-red-700 transition-all inline-flex items-center gap-2"
                >
                  <PlusCircle className="w-4 h-4" />
                  Create First Campaign
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {myCampaigns.map(camp => {
                  const progress = Math.min(100, Math.round((camp.currentCompleted / camp.targetQuantity) * 100));
                  const isDone = camp.currentCompleted >= camp.targetQuantity;

                  return (
                    <div
                      key={camp.id}
                      className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3.5 w-full md:w-auto">
                        <img
                          src={camp.thumbnailUrl}
                          alt={camp.videoTitle}
                          className="w-20 h-14 sm:w-28 sm:h-16 rounded-xl object-cover bg-slate-950 shrink-0"
                        />
                        <div className="space-y-1 min-w-0">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate max-w-[280px] sm:max-w-md">
                            {camp.videoTitle}
                          </h4>
                          <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                            <span className="capitalize font-semibold text-red-600 dark:text-red-400">
                              {camp.type === 'sub_watch' ? 'Sub + 30s' : camp.type === 'view_watch' ? '45s View' : '15s Quick'}
                            </span>
                            <span>•</span>
                            <span className="text-amber-600 dark:text-amber-400 font-bold">
                              {camp.rewardCoins} coins / user
                            </span>
                            <span>•</span>
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                              camp.status === 'completed' 
                                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                                : camp.status === 'paused'
                                ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                                : 'bg-blue-100 dark:bg-blue-950 text-blue-600'
                            }`}>
                              {camp.status}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Progress & Actions */}
                      <div className="flex items-center justify-between md:justify-end gap-4 w-full md:w-auto border-t md:border-t-0 pt-3 md:pt-0 border-slate-200 dark:border-slate-700">
                        <div className="text-left md:text-right min-w-[130px]">
                          <div className="flex justify-between md:justify-end gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                            <span>{camp.currentCompleted}/{camp.targetQuantity} delivered</span>
                            <span className="text-slate-400">({progress}%)</span>
                          </div>
                          <div className="w-32 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mt-1 overflow-hidden">
                            <div
                              className="h-full bg-red-600 rounded-full"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>

                        {/* Controls: Pause/Resume, Delete & Refund */}
                        <div className="flex items-center gap-1.5">
                          {!isDone && (
                            <button
                              onClick={() => togglePauseCampaign(camp.id)}
                              title={camp.status === 'paused' ? 'Resume Campaign' : 'Pause Campaign'}
                              className="p-2 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition-colors"
                            >
                              {camp.status === 'paused' ? <Play className="w-4 h-4 text-emerald-500 fill-emerald-500" /> : <Pause className="w-4 h-4" />}
                            </button>
                          )}

                          <button
                            onClick={() => {
                              if (window.confirm('Delete this campaign? Remaining uncompleted coins will be refunded to your wallet.')) {
                                deleteCampaign(camp.id);
                              }
                            }}
                            title="Delete Campaign & Refund Uncompleted Coins"
                            className="p-2 rounded-xl bg-red-100 hover:bg-red-200 dark:bg-red-950/60 dark:hover:bg-red-900/80 text-red-600 dark:text-red-400 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Completed Tasks */}
        {activeTabSub === 'task_history' && (
          <div className="p-4 sm:p-6">
            {completedTasks.length === 0 ? (
              <div className="py-10 text-center space-y-2">
                <p className="text-xs text-slate-500">You have not completed any tasks yet.</p>
                <button
                  onClick={() => setActiveTab('earn')}
                  className="text-xs font-bold text-red-600 hover:underline inline-flex items-center gap-1"
                >
                  <span>Explore Earn Tasks</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {completedTasks.map(task => (
                  <div key={task.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[240px] sm:max-w-md">
                          {task.campaignTitle}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          Channel: {task.channelName} • {new Date(task.completedAt).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>

                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 shrink-0">
                      <Coins className="w-3.5 h-3.5" />
                      +{task.rewardCoins} Coins
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Transactions Log */}
        {activeTabSub === 'transactions' && (
          <div className="p-4 sm:p-6">
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {transactions.map(tx => {
                const isEarn = tx.amount > 0;
                return (
                  <div key={tx.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                        isEarn
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : 'bg-red-500/10 text-red-600 dark:text-red-400'
                      }`}>
                        {isEarn ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          {tx.description}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {new Date(tx.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <span className={`text-xs font-mono font-bold flex items-center gap-1 shrink-0 ${
                      isEarn ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                    }`}>
                      {isEarn ? `+${tx.amount}` : tx.amount} Coins
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
