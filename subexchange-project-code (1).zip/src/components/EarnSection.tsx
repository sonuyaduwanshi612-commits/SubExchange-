import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Campaign, CampaignType } from '../types';
import { 
  Play, 
  Coins, 
  CheckCircle2, 
  Search, 
  Filter, 
  Clock, 
  Youtube, 
  Sparkles,
  ExternalLink,
  Flame,
  ArrowRight,
  PlusCircle
} from 'lucide-react';

interface EarnSectionProps {
  onOpenAuth: () => void;
}

export const EarnSection: React.FC<EarnSectionProps> = ({ onOpenAuth }) => {
  const { 
    campaigns, 
    currentUser, 
    setActiveWatchTask, 
    setActiveTab 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<CampaignType | 'all'>('all');

  // Filter campaigns
  const filteredCampaigns = campaigns.filter(campaign => {
    // Hide paused campaigns unless user is creator
    if (campaign.status === 'paused') return false;

    // Filter by type
    if (selectedType !== 'all' && campaign.type !== selectedType) return false;

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = campaign.videoTitle.toLowerCase().includes(q);
      const matchChannel = campaign.creatorChannel.toLowerCase().includes(q);
      if (!matchTitle && !matchChannel) return false;
    }

    return true;
  });

  const handleStartTask = (campaign: Campaign) => {
    if (!currentUser) {
      onOpenAuth();
      return;
    }
    setActiveWatchTask(campaign);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Top Banner / Welcome Callout */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-red-700 via-rose-600 to-amber-600 text-white p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Community Sub & View Exchange</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight">
            Watch, Subscribe & Earn Coins
          </h1>

          <p className="text-xs sm:text-sm text-white/90 leading-relaxed">
            Support fellow creators to earn coins. Then spend your earned coins to boost your own YouTube channel with genuine subscribers and real view time!
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              id="btn-hero-create"
              onClick={() => setActiveTab('create')}
              className="px-4 py-2 rounded-xl bg-white text-slate-900 hover:bg-slate-100 text-xs sm:text-sm font-bold flex items-center gap-2 shadow-lg transition-all"
            >
              <PlusCircle className="w-4 h-4 text-red-600" />
              <span>Create Your Campaign</span>
            </button>

            {currentUser && (
              <div className="px-3.5 py-1.5 rounded-xl bg-black/20 backdrop-blur-md border border-white/20 text-xs font-semibold flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-300" />
                <span>Your Balance: <strong className="text-amber-300">{currentUser.coins} Coins</strong></span>
              </div>
            )}
          </div>
        </div>

        {/* Decorative background circle */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 rounded-full bg-white/10 blur-2xl pointer-events-none" />
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white dark:bg-slate-900/80 p-3 sm:p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            id="input-search-tasks"
            type="text"
            placeholder="Search campaigns by video title or channel..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
          />
        </div>

        {/* Filter chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            id="filter-type-all"
            onClick={() => setSelectedType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedType === 'all'
                ? 'bg-red-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            All ({campaigns.filter(c => c.status !== 'paused').length})
          </button>
          
          <button
            id="filter-type-sub"
            onClick={() => setSelectedType('sub_watch')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedType === 'sub_watch'
                ? 'bg-red-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            Sub + Watch
          </button>

          <button
            id="filter-type-view"
            onClick={() => setSelectedType('view_watch')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedType === 'view_watch'
                ? 'bg-red-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            Watch Only
          </button>

          <button
            id="filter-type-quick"
            onClick={() => setSelectedType('quick_view')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedType === 'quick_view'
                ? 'bg-red-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            Quick 10s
          </button>
        </div>

      </div>

      {/* Campaign Cards Grid */}
      {filteredCampaigns.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400">
            <Youtube className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            No matching campaigns found
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            Try adjusting your search query or be the first to launch a new campaign for other creators to complete!
          </p>
          <button
            onClick={() => setActiveTab('create')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-bold shadow-md hover:bg-red-700 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            Launch First Campaign
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {filteredCampaigns.map(campaign => {
            const isCompleted = currentUser ? campaign.completedUserIds.includes(currentUser.id) : false;
            const isOwn = currentUser ? campaign.creatorId === currentUser.id : false;
            const isFull = campaign.currentCompleted >= campaign.targetQuantity;
            const progress = Math.min(100, Math.round((campaign.currentCompleted / campaign.targetQuantity) * 100));

            return (
              <div
                key={campaign.id}
                id={`campaign-card-${campaign.id}`}
                className={`group rounded-3xl bg-white dark:bg-slate-900/90 border transition-all duration-200 flex flex-col overflow-hidden shadow-sm hover:shadow-md ${
                  isCompleted
                    ? 'border-emerald-500/30 dark:border-emerald-500/20'
                    : 'border-slate-200 dark:border-slate-800/80 hover:border-red-500/40'
                }`}
              >
                {/* Thumbnail Header with Duration Badge & Reward */}
                <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
                  <img
                    src={campaign.thumbnailUrl}
                    alt={campaign.videoTitle}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />

                  {/* Coin Reward Badge */}
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs flex items-center gap-1 shadow-lg">
                    <Coins className="w-3.5 h-3.5 text-slate-950" />
                    <span>+{campaign.rewardCoins} Coins</span>
                  </div>

                  {/* Type / Watch Duration Badge */}
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 text-white text-[11px] font-bold flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-red-400" />
                    <span>{campaign.requiredWatchSeconds}s</span>
                    <span className="text-slate-400">•</span>
                    <span className="capitalize">
                      {campaign.type === 'sub_watch' ? 'Subscribe' : 'Watch'}
                    </span>
                  </div>

                  {/* Play icon overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center shadow-xl transform scale-90 group-hover:scale-100 transition-transform">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>

                  {/* Channel tag on bottom of thumbnail */}
                  <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-white">
                    <div className="flex items-center gap-1.5 truncate max-w-[70%]">
                      <div className="w-5 h-5 rounded-full bg-red-600 flex items-center justify-center text-[10px] font-bold shrink-0">
                        {campaign.creatorChannel.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-semibold truncate">
                        {campaign.creatorChannel}
                      </span>
                    </div>

                    <span className="text-[10px] text-slate-300 shrink-0">
                      {campaign.currentCompleted}/{campaign.targetQuantity} delivered
                    </span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white line-clamp-2 leading-snug group-hover:text-red-500 transition-colors">
                      {campaign.videoTitle}
                    </h3>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-medium text-slate-500 dark:text-slate-400">
                      <span>Campaign Goal</span>
                      <span>{progress}% filled</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-red-600 to-amber-500 rounded-full"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Action Button */}
                  <div>
                    {isCompleted ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Completed (Reward Claimed)</span>
                      </div>
                    ) : isOwn ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-bold flex items-center justify-center gap-1.5">
                        <span>Your Own Campaign</span>
                      </div>
                    ) : isFull ? (
                      <div className="w-full py-2.5 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-bold flex items-center justify-center gap-1.5">
                        <span>Goal Reached (Completed)</span>
                      </div>
                    ) : (
                      <button
                        id={`btn-watch-task-${campaign.id}`}
                        onClick={() => handleStartTask(campaign)}
                        className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md shadow-red-600/20 flex items-center justify-center gap-2 transition-all group-hover:shadow-red-600/30"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>Watch & Earn +{campaign.rewardCoins} Coins</span>
                      </button>
                    )}
                  </div>

                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
