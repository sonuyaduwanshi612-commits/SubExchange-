import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Youtube, 
  Mail, 
  User as UserIcon, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck,
  Zap
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login, signup, loginAsDemo } = useApp();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [channelName, setChannelName] = useState('');
  const [channelUrl, setChannelUrl] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (mode === 'signup') {
      if (!name.trim()) {
        setError('Please provide your name');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setError('Please provide a valid email address');
        return;
      }
      if (!channelUrl.trim()) {
        setError('Please provide your YouTube channel link');
        return;
      }

      signup(name, email, channelName || `${name}'s Channel`, channelUrl);
      onClose();
    } else {
      if (!email.trim()) {
        setError('Please enter your email');
        return;
      }
      const success = login(email);
      if (success) {
        onClose();
      } else {
        setError('No creator account found with this email. Please sign up or try demo.');
      }
    }
  };

  const handleDemoClick = () => {
    loginAsDemo();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="auth-modal-dialog"
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
      >
        {/* Header Graphic */}
        <div className="relative p-6 bg-gradient-to-br from-red-600 via-rose-600 to-amber-600 text-white overflow-hidden">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/20 hover:bg-black/30 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>🎁 50 Free Welcome Coins</span>
          </div>

          <h2 className="text-2xl font-extrabold tracking-tight">
            {mode === 'signup' ? 'Join SubExchange' : 'Welcome Back, Creator'}
          </h2>
          <p className="text-xs text-white/90 mt-1">
            {mode === 'signup'
              ? 'Exchange subscribers, watch time, and grow your channel together.'
              : 'Log in to continue managing campaigns and earning coins.'}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 p-1">
          <button
            id="tab-auth-signup"
            type="button"
            onClick={() => { setMode('signup'); setError(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'signup'
                ? 'bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Create Account (+50 Coins)
          </button>
          <button
            id="tab-auth-login"
            type="button"
            onClick={() => { setMode('login'); setError(null); }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
              mode === 'login'
                ? 'bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 shadow-sm'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Log In
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 text-red-700 dark:text-red-300 text-xs font-medium">
              {error}
            </div>
          )}

          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Creator Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="input-signup-name"
                    type="text"
                    required
                    placeholder="e.g. Maya Lin"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  YouTube Channel Name
                </label>
                <input
                  id="input-signup-channel-name"
                  type="text"
                  placeholder="e.g. Maya Tech Reviews"
                  value={channelName}
                  onChange={e => setChannelName(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                  <span>YouTube Channel Link</span>
                  <span className="text-[10px] text-slate-400 font-normal">e.g. @MyChannel</span>
                </label>
                <div className="relative">
                  <Youtube className="w-4 h-4 text-red-500 absolute left-3 top-3" />
                  <input
                    id="input-signup-channel-url"
                    type="text"
                    required
                    placeholder="https://youtube.com/@YourChannel"
                    value={channelUrl}
                    onChange={e => setChannelUrl(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
                  />
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                id="input-auth-email"
                type="email"
                required
                placeholder="creator@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 dark:text-amber-300 font-medium">
                Instant starter grant: You will receive <strong>50 bonus coins</strong> credited directly into your wallet upon signup!
              </p>
            </div>
          )}

          <button
            id="btn-auth-submit"
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow-md shadow-red-600/25 flex items-center justify-center gap-2 transition-all"
          >
            <span>{mode === 'signup' ? 'Claim 50 Coins & Get Started' : 'Log In to Account'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Quick Demo Login Shortcut */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-200 dark:border-slate-800 text-center">
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
            Want to test without filling details?
          </p>
          <button
            id="btn-auth-demo"
            type="button"
            onClick={handleDemoClick}
            className="w-full py-2 px-3 rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-colors border border-slate-300 dark:border-slate-700"
          >
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>One-Click Demo Creator Login (Alex Builds Stuff)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
