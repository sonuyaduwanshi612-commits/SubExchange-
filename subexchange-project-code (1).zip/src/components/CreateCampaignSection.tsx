import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { CampaignType } from '../types';
import { extractYouTubeVideoId, getYouTubeThumbnailUrl } from '../utils/youtube';
import { 
  PlusCircle, 
  Youtube, 
  Coins, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  Clock, 
  TrendingUp, 
  Users, 
  Eye,
  Gift
} from 'lucide-react';

interface CreateCampaignSectionProps {
  onOpenAuth: () => void;
  onOpenWallet: () => void;
}

export const CreateCampaignSection: React.FC<CreateCampaignSectionProps> = ({
  onOpenAuth,
  onOpenWallet
}) => {
  const { currentUser, createCampaign, setActiveTab, claimDailyBonus } = useApp();

  // Form State
  const [videoUrl, setVideoUrl] = useState('');
  const [videoTitle, setVideoTitle] = useState('');
  const [campaignType, setCampaignType] = useState<CampaignType>('sub_watch');
  const [targetQuantity, setTargetQuantity] = useState<number>(10);
  const [rewardCoins, setRewardCoins] = useState<number>(10);
  
  // Feedback states
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Derived video ID & thumbnail
  const detectedVideoId = extractYouTubeVideoId(videoUrl);
  const thumbnailPreview = detectedVideoId ? getYouTubeThumbnailUrl(detectedVideoId) : null;

  // Auto-fill a placeholder title if user pastes a recognized video
  useEffect(() => {
    if (detectedVideoId && !videoTitle) {
      if (currentUser?.channelName) {
        setVideoTitle(`${currentUser.channelName} - New Video Release`);
      } else {
        setVideoTitle('My YouTube Video');
      }
    }
  }, [detectedVideoId, currentUser]);

  // Adjust watch seconds based on type
  const requiredWatchSeconds = 
    campaignType === 'sub_watch' ? 30 :
    campaignType === 'view_watch' ? 45 : 15;

  const totalCost = targetQuantity * rewardCoins;
  const userCoins = currentUser ? currentUser.coins : 0;
  const hasEnoughCoins = userCoins >= totalCost;
  const remainingCoins = userCoins - totalCost;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!videoUrl.trim()) {
      setErrorMsg('Please enter a YouTube video URL');
      return;
    }

    if (targetQuantity < 1) {
      setErrorMsg('Minimum quantity is 1');
      return;
    }

    if (rewardCoins < 5) {
      setErrorMsg('Minimum coin reward per user is 5 coins');
      return;
    }

    if (!hasEnoughCoins) {
      setErrorMsg(`Insufficient coins. You need ${totalCost} coins, but your balance is ${userCoins} coins.`);
      return;
    }

    setIsSubmitting(true);

    const result = createCampaign({
      videoUrl: videoUrl.trim(),
      videoTitle: videoTitle.trim() || `${currentUser.channelName} Video`,
      type: campaignType,
      requiredWatchSeconds,
      targetQuantity,
      rewardCoins,
    });

    setIsSubmitting(false);

    if (result.success) {
      setSuccessMsg(result.message);
      // Reset form
      setVideoUrl('');
      setVideoTitle('');
      setTimeout(() => {
        setActiveTab('earn');
      }, 2000);
    } else {
      setErrorMsg(result.message);
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-xl mx-auto p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center space-y-4 shadow-sm my-8">
        <div className="w-14 h-14 rounded-2xl bg-red-600/10 text-red-600 dark:text-red-400 mx-auto flex items-center justify-center">
          <Youtube className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
          Sign In to Launch a Campaign
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          Create an account to receive 50 free bonus coins instantly and launch your first subscriber & view campaign.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold shadow-md shadow-red-600/20 transition-all"
        >
          Sign In / Register (+50 Coins)
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20">
      
      {/* Header */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20 text-xs font-bold">
          <TrendingUp className="w-3.5 h-3.5" />
          <span>YouTube Growth Campaign</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
          Promote Your YouTube Video
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
          Set up a campaign with your coins. Other creators will watch your video and subscribe to earn the reward you offer.
        </p>
      </div>

      {/* Success banner */}
      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm font-bold flex items-center gap-2.5 animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
          <span>{successMsg} Redirecting to public feed...</span>
        </div>
      )}

      {/* Error banner */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-700 dark:text-red-300 text-xs sm:text-sm font-bold flex items-center gap-2.5 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Step 1: Video URL & Preview */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[11px] font-black flex items-center justify-center">1</span>
            Enter YouTube Video
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
              YouTube Video or Shorts Link
            </label>
            <div className="relative">
              <Youtube className="w-5 h-5 text-red-500 absolute left-3.5 top-3" />
              <input
                id="input-campaign-url"
                type="url"
                required
                placeholder="https://www.youtube.com/watch?v=... or youtu.be/..."
                value={videoUrl}
                onChange={e => setVideoUrl(e.target.value)}
                className="w-full pl-11 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all"
              />
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              Tip: Paste standard watch links (e.g. youtube.com/watch?v=...) or YouTube shorts.
            </p>
          </div>

          {/* Live Preview Card */}
          {detectedVideoId && (
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row items-center gap-3">
              <div className="relative w-full sm:w-40 aspect-video rounded-xl overflow-hidden bg-slate-950 shrink-0">
                <img
                  src={thumbnailPreview || ''}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/70 text-[9px] font-bold text-white">
                  Live Detected
                </div>
              </div>

              <div className="flex-1 w-full space-y-1.5">
                <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400">
                  Video Title (Editable)
                </label>
                <input
                  id="input-campaign-title"
                  type="text"
                  value={videoTitle}
                  onChange={e => setVideoTitle(e.target.value)}
                  placeholder="Enter title for your campaign..."
                  className="w-full px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                />
                <p className="text-[10px] text-slate-400">
                  Promoted under your channel: <strong>{currentUser.channelName}</strong>
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Step 2: Campaign Goals & Requirements */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[11px] font-black flex items-center justify-center">2</span>
            Campaign Type & Watch Requirements
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            {/* Option 1: Subscribe & Watch */}
            <div
              id="opt-type-sub"
              onClick={() => setCampaignType('sub_watch')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                campaignType === 'sub_watch'
                  ? 'border-red-500 bg-red-500/5 dark:bg-red-500/10 ring-2 ring-red-500/20'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Users className={`w-5 h-5 ${campaignType === 'sub_watch' ? 'text-red-500' : 'text-slate-400'}`} />
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-950 text-red-600 dark:text-red-400">
                  Best Value
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Subscribers + 30s Watch
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Subscribers watch 30s before subscribing for high retention.
              </p>
            </div>

            {/* Option 2: Long View */}
            <div
              id="opt-type-view"
              onClick={() => setCampaignType('view_watch')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                campaignType === 'view_watch'
                  ? 'border-red-500 bg-red-500/5 dark:bg-red-500/10 ring-2 ring-red-500/20'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Eye className={`w-5 h-5 ${campaignType === 'view_watch' ? 'text-red-500' : 'text-slate-400'}`} />
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                  45s Watch
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                High Retention Views
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                45-second verified view time to boost YouTube algorithm ranking.
              </p>
            </div>

            {/* Option 3: Quick View */}
            <div
              id="opt-type-quick"
              onClick={() => setCampaignType('quick_view')}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                campaignType === 'quick_view'
                  ? 'border-red-500 bg-red-500/5 dark:bg-red-500/10 ring-2 ring-red-500/20'
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <Clock className={`w-5 h-5 ${campaignType === 'quick_view' ? 'text-red-500' : 'text-slate-400'}`} />
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
                  15s Quick
                </span>
              </div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Fast Exposure Views
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Fast 15-second view session for rapid viral reach and views.
              </p>
            </div>

          </div>
        </div>

        {/* Step 3: Target Quantity & Coin Reward */}
        <div className="p-5 sm:p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[11px] font-black flex items-center justify-center">3</span>
            Target Quantity & Coin Reward
          </h3>

          {/* Quantity selector */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>Target Subscribers/Views</span>
              <span className="text-red-600 dark:text-red-400 font-extrabold text-sm">{targetQuantity} Creators</span>
            </div>

            <div className="flex items-center gap-2">
              {[5, 10, 20, 50, 100].map(amt => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setTargetQuantity(amt)}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all ${
                    targetQuantity === amt
                      ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-950 border-transparent shadow'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
          </div>

          {/* Reward per Task */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>Reward per Creator</span>
              <span className="text-amber-500 font-extrabold text-sm flex items-center gap-1">
                <Coins className="w-4 h-4" />
                +{rewardCoins} Coins
              </span>
            </div>

            <div className="flex items-center gap-3">
              <input
                id="range-coin-reward"
                type="range"
                min="5"
                max="30"
                step="1"
                value={rewardCoins}
                onChange={e => setRewardCoins(Number(e.target.value))}
                className="flex-1 accent-amber-500 cursor-pointer"
              />
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 min-w-[55px] text-center">
                {rewardCoins} c
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Higher rewards incentivize creators to complete your task first on the public task list.
            </p>
          </div>
        </div>

        {/* Step 4: Cost Calculation & Wallet Status */}
        <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Campaign Budget Summary
            </span>
            <div className="flex items-center gap-1 text-xs font-semibold text-amber-400">
              <Coins className="w-3.5 h-3.5" />
              <span>Current Balance: {userCoins} Coins</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 p-3 rounded-2xl bg-slate-950/60 border border-slate-800 text-center">
            <div>
              <p className="text-[10px] text-slate-400">Quantity</p>
              <p className="text-sm font-bold text-white mt-0.5">{targetQuantity}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400">Reward</p>
              <p className="text-sm font-bold text-amber-400 mt-0.5">{rewardCoins} c</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400">Total Required</p>
              <p className="text-sm font-black text-amber-300 mt-0.5">{totalCost} Coins</p>
            </div>
          </div>

          {/* Insufficient Coins warning & shortcuts */}
          {!hasEnoughCoins ? (
            <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-500/40 space-y-2">
              <div className="flex items-center gap-2 text-red-300 text-xs font-bold">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span>You need {totalCost - userCoins} more coins to launch this campaign</span>
              </div>
              <p className="text-[11px] text-red-200/80">
                You can lower your target quantity/reward, claim your daily bonus, or watch videos on the Earn tab to get free coins!
              </p>
              <div className="pt-1 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('earn')}
                  className="px-3 py-1.5 rounded-xl bg-white text-slate-950 text-xs font-bold hover:bg-slate-100 transition-colors"
                >
                  Watch Videos to Earn
                </button>
                <button
                  type="button"
                  onClick={claimDailyBonus}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 transition-colors flex items-center gap-1.5"
                >
                  <Gift className="w-3.5 h-3.5" />
                  Claim Daily +15
                </button>
              </div>
            </div>
          ) : (
            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Balance after campaign launch:</span>
              <strong className="text-emerald-400">{remainingCoins} Coins remaining</strong>
            </div>
          )}

          {/* Submit Button */}
          <button
            id="btn-submit-campaign"
            type="submit"
            disabled={!hasEnoughCoins || isSubmitting}
            className={`w-full py-3 px-4 rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
              hasEnoughCoins
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-700 hover:to-red-700 text-white shadow-red-600/30 hover:scale-[1.01] cursor-pointer'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>
              {isSubmitting 
                ? 'Publishing Campaign...' 
                : `Launch Campaign (-${totalCost} Coins)`}
            </span>
          </button>
        </div>

      </form>

    </div>
  );
};
