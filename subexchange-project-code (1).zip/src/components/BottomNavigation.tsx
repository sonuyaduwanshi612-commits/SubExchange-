import React from 'react';
import { useApp } from '../context/AppContext';
import { Play, PlusCircle, Layers, Coins, User } from 'lucide-react';

interface BottomNavigationProps {
  onOpenWallet: () => void;
  onOpenAuth: () => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({ onOpenWallet, onOpenAuth }) => {
  const { activeTab, setActiveTab, currentUser } = useApp();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-950/95 border-t border-slate-200 dark:border-slate-800/80 backdrop-blur-lg px-2 py-1.5 safe-area-pb">
      <div className="grid grid-cols-4 items-center gap-1">
        
        {/* Tab 1: Earn Coins */}
        <button
          id="btn-bottom-nav-earn"
          onClick={() => setActiveTab('earn')}
          className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all ${
            activeTab === 'earn'
              ? 'text-red-600 dark:text-red-500 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'earn' ? 'bg-red-50 dark:bg-red-950/50' : ''}`}>
            <Play className="w-5 h-5 fill-current" />
          </div>
          <span className="text-[10px] mt-0.5">Earn</span>
        </button>

        {/* Tab 2: Create Campaign (Elevated button) */}
        <button
          id="btn-bottom-nav-create"
          onClick={() => setActiveTab('create')}
          className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all ${
            activeTab === 'create'
              ? 'text-red-600 dark:text-red-500 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'create' ? 'bg-red-50 dark:bg-red-950/50' : ''}`}>
            <PlusCircle className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Create</span>
        </button>

        {/* Tab 3: Wallet */}
        <button
          id="btn-bottom-nav-wallet"
          onClick={() => {
            if (!currentUser) {
              onOpenAuth();
            } else {
              onOpenWallet();
            }
          }}
          className="flex flex-col items-center justify-center py-1.5 rounded-xl text-amber-600 dark:text-amber-400 font-bold transition-all"
        >
          <div className="p-1 rounded-lg bg-amber-500/10 dark:bg-amber-500/20">
            <Coins className="w-5 h-5 text-amber-500" />
          </div>
          <span className="text-[10px] mt-0.5">
            {currentUser ? `${currentUser.coins} c` : 'Wallet'}
          </span>
        </button>

        {/* Tab 4: Dashboard / Profile */}
        <button
          id="btn-bottom-nav-dashboard"
          onClick={() => {
            if (!currentUser) {
              onOpenAuth();
            } else {
              setActiveTab('dashboard');
            }
          }}
          className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-all ${
            activeTab === 'dashboard'
              ? 'text-red-600 dark:text-red-500 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className={`p-1 rounded-lg ${activeTab === 'dashboard' ? 'bg-red-50 dark:bg-red-950/50' : ''}`}>
            <User className="w-5 h-5" />
          </div>
          <span className="text-[10px] mt-0.5">Profile</span>
        </button>

      </div>
    </div>
  );
};
