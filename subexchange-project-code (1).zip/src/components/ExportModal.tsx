import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Github, 
  CheckCircle2, 
  FileArchive, 
  Terminal, 
  Copy, 
  Check, 
  Sparkles,
  ExternalLink,
  FolderGit2
} from 'lucide-react';
import { downloadProjectZip } from '../utils/exportZip';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string>('');
  const [downloadComplete, setDownloadComplete] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setDownloading(true);
      setDownloadComplete(false);
      await downloadProjectZip((status) => {
        setDownloadStatus(status);
      });
      setDownloadComplete(true);
    } catch (err) {
      console.error(err);
      setDownloadStatus('Download failed. Please try again.');
    } finally {
      setDownloading(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const gitCommands = [
    '# 1. Unzip the downloaded file and open terminal:',
    'cd subexchange-project-code',
    '# 2. Initialize git repository:',
    'git init',
    'git add .',
    'git commit -m "Initial commit - SubExchange Creator App"',
    '# 3. Create a new repo on GitHub, then link & push:',
    'git branch -M main',
    'git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git',
    'git push -u origin main'
  ].join('\n');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div 
        id="export-modal-container"
        className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-600/10 dark:bg-red-500/20 text-red-600 dark:text-red-400 flex items-center justify-center font-bold">
              <FileArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                Download Code & GitHub Export
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Poora source code (.zip) download karein ya GitHub par export karein
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          
          {/* Option 1: Direct 1-Click ZIP Download */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-red-500/5 via-rose-500/5 to-amber-500/5 border border-red-500/20 dark:border-red-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider">
                  Option 1
                </span>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-red-500" />
                  Direct 1-Click ZIP Download
                </h4>
              </div>
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Ready
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Yeh button click karte hi aapke browser mein poora source code (<code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded text-[11px]">src/</code>, <code className="bg-slate-200 dark:bg-slate-800 px-1 py-0.5 rounded text-[11px]">package.json</code>, components, styling, config) turant ek <strong className="font-semibold text-slate-900 dark:text-white">.ZIP file</strong> mein download ho jayega.
            </p>

            <button
              id="btn-trigger-zip-download"
              onClick={handleDownload}
              disabled={downloading}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-red-600 hover:bg-red-700 active:scale-[0.99] text-white font-bold text-sm shadow-lg shadow-red-600/25 transition-all disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${downloading ? 'animate-bounce' : ''}`} />
              {downloading ? downloadStatus || 'Generating ZIP...' : 'Download Project ZIP Now (.zip)'}
            </button>

            {downloadComplete && (
              <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>ZIP download shuru ho gaya hai! Isme README.md aur setup instructions bhi included hain.</span>
              </div>
            )}
          </div>

          {/* Option 2: AI Studio Top-Bar Native Export to GitHub */}
          <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-slate-800 dark:bg-slate-700 text-white text-[10px] font-bold uppercase tracking-wider">
                Option 2
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Github className="w-4 h-4 text-slate-900 dark:text-white" />
                AI Studio Ke Top Bar Se Direct GitHub Export
              </h4>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              Google AI Studio ke interface mein upar daayein taraf (top-right bar mein):
            </p>

            <ol className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-decimal list-inside pl-1">
              <li>Upar right corner mein <strong className="text-slate-900 dark:text-white font-semibold">Settings (⚙️)</strong> ya <strong className="text-slate-900 dark:text-white font-semibold">Share</strong> ke paas teen dots <strong className="text-slate-900 dark:text-white font-semibold">(...)</strong> par click karein.</li>
              <li>Wahan <strong className="text-slate-900 dark:text-white font-semibold">"Export to GitHub"</strong> option chunein.</li>
              <li>Apne GitHub account ko authorize karein aur Repository name dekar <strong className="text-slate-900 dark:text-white font-semibold">Export</strong> par click karein. AI Studio sidhe aapke GitHub par code push kar dega!</li>
            </ol>
          </div>

          {/* Option 3: Command Line Git Push */}
          <div className="p-5 rounded-2xl bg-slate-950 text-slate-300 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>ZIP Download Ke Baad GitHub Par Dalne Ke Commands:</span>
              </div>
              <button
                onClick={() => copyToClipboard(gitCommands, 1)}
                className="flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                {copiedIndex === 1 ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Commands</span>
                  </>
                )}
              </button>
            </div>

            <pre className="text-[11px] font-mono bg-slate-900 p-3 rounded-xl overflow-x-auto text-emerald-400 leading-relaxed border border-slate-800">
              {gitCommands}
            </pre>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            SubExchange • Full TypeScript & React Source
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-semibold text-xs hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
