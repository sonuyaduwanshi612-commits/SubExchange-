export interface User {
  id: string;
  name: string;
  email: string;
  channelName: string;
  channelUrl: string;
  coins: number;
  totalEarned: number;
  totalSpent: number;
  joinedAt: string;
  lastDailyBonusClaim?: string;
  avatarUrl?: string;
}

export type CampaignType = 'sub_watch' | 'view_watch' | 'quick_view';

export interface Campaign {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorChannel: string;
  creatorChannelUrl: string;
  videoUrl: string;
  videoId: string;
  videoTitle: string;
  thumbnailUrl: string;
  type: CampaignType;
  requiredWatchSeconds: number;
  rewardCoins: number;
  targetQuantity: number;
  currentCompleted: number;
  status: 'active' | 'completed' | 'paused';
  createdAt: string;
  completedUserIds: string[]; // users who have finished this task
}

export interface CoinTransaction {
  id: string;
  userId: string;
  amount: number; // positive for earn, negative for spend
  type: 'bonus' | 'task_reward' | 'campaign_create' | 'campaign_refund' | 'daily_claim';
  description: string;
  timestamp: string;
  referenceId?: string;
}

export interface TaskCompletionLog {
  id: string;
  userId: string;
  campaignId: string;
  campaignTitle: string;
  channelName: string;
  rewardCoins: number;
  completedAt: string;
}
